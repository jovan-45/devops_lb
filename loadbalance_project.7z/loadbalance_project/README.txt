******************************HAproxy Load balancing to Nginx webservers with vagrant on virtualbox engine*************
############################################################################################
Tools and softwares used:
############################################################################################
Host OS: windows
powershell: 2.0
vagrant: 2.2.5
virtualbox: 6.0.12
vagrant boxes(vms): centos/7 
haproxy:  1.5.18
nginx:    1.16.0
##########################################################################################

Once successfull cloning of zip for the github

unzip the project_lb zip file

Find the dirctory structure as:
  conf_files
    default_web1.conf
    default_web1.conf
    haproxy.cfg
    nginx.conf
  nginx rpm
  Vagrantfile

############################################################################################
download vagrant: https://www.vagrantup.com/downloads.html
download virtual box / extention pack: https://www.virtualbox.org/wiki/Downloads
download powershell: https://www.microsoft.com/en-in/download/confirmation.aspx?id=2560
############################################################################################

install powershell 2.0 on host
Followed by virtual box engine with extention and vagrant installation.

Now create a project directory and proceed for below steps to steup vagrant environment.

Before proceeding to provisinig of vms disable Hyper-V launcher in windows as:

  bcdedit /set hypervisorlaunchtype off  

the above command helps vagrant to look into its default engine virtualbox as mentioned in vagrantfile.

  cd directory_name
  vagrant init

The above commands creates a Vagrantfile.
Replace the newly created vagrantfile by downloaded Vagrantfile from github, which contains 
  ONE LOADBALANCER AND TWO WEBSERVERS ENVIRONMENT.
	
Now proceed for provision of 3 vms by:
 
 vagrant up

 the above command will take few minutes to provision our 3 servers.
 
 once after booting vms, check for the status of vms by command vagrant status

 the vagrant file will give hostnames to 3 servers as lb,web1,web2

 Log in to the load balancer using SSH and add the Nginx web servers IP addresses and hostnames in /etc/hosts file as root:

   10.0.15.21 web1
   10.0.15.22 web2

 Next, log into each of the Web servers (web1 and web2) and edit the /etc/hosts file to point to the load balancer:

   10.0.15.11 lb

####################################################################################################
loadbalancer setup
####################################################################################################

 Login to loadbalncer to install haproxy, the HAProxy repository is available on the CentOS repository,
    install HAProxy using the command:
    
    yum install haproxy -y

 Once the installation is successful and complete, head into the haproxy directory.

    cd /etc/haproxy
   replace haproxy.cfg  from previously downloaded zip file with haproxy.cfg  file.

 Next, We are going to configure the rsyslog daemon to log the HAProxy statistics. 
 Edit the rsyslog.conf file to enable the UDP port 514 to be used by rsyslog.

   vi /etc/rsyslog.conf
 
 To allow UDP connection via port 154, uncomment the following lines.
 
   $ModLoad imudp
   $UDPServerRun 514
  
 Next, create a new HAProxy configuration file for syslog.

	vi /etc/rsyslog.d/haproxy.conf

 Paste the following configuration

	local2.=info     /var/log/haproxy-access.log    #For Access Log
	local2.notice    /var/log/haproxy-info.log      #For Service Info - webservers,loadbalancer  

 Proceed and restart rsyslog.
	
 	systemctl restart rsyslog

 Next, start and enable Haproxy to start at boot up.

	systemctl start haproxy
	systemctl enable haproxy

############################################
websevers setup
############################################

Login to webservers to install nginx, the nginx repository is available on the CentOS repository if not copy the rpm from zipped file:
install scp in powershell:

vagrant plugin install vagrant-scp

copy the nginx rpm to serevers:

	vagrant scp nginx-1.16.0-1.el7.ngx.x86_64.rpm  web1:/home/vagrant/  #for web1 nginx
 	vagrant scp nginx-1.16.0-1.el7.ngx.x86_64.rpm  web2:/home/vagrant/  #for web2 nginx 


After successfull copy login to individual servers:

install nginx as:

 	cd /home/vagrant/
 	yum install nginx-1.16.0-1.el7.ngx.x86_64.rpm -y

Next, copy the default_web1.conf/default_web2.conf into servers under /etc/nginx/conf.d/ from zipped file

With Nginx installed on both servers, we are going to modify the index.html files in each of the Nginx web servers in order to create a distinction between each server when simulating with the HAproxy load balancer.
Move to the html directory as shown:

	cd /usr/share/nginx/html/index.html

	<h1>Hello world from web1</h1>

similarly for web2:

	cd /usr/share/nginx/html/index.html

	<h1>Hello world from web2</h1>

Next, start Nginx in both web servers and confirm if the service is running

	systemctl start  nginx
	systemctl status nginx

Testing Load balancing:

To verify that everything went well, run the following command repeatedly.

	curl lb

We will be getting the desired output in roundrobin manner.

Also try stopping one of the nginx web servers and run the command:

	curl lb

Request should be serverd by another server.

################################################ PROS AND CONS OF MY SOLUTION ##########################
pros:

Ease of spining up vms with vagrant and virtual box.
Using roundrobin algorithm for loadbalancing as Round Robin selects servers in turns.
Also HAProxy uses health checks to determine if a backend server is available to process requests. This avoids having to manually remove a server from the backend if it becomes unavailable.
very usefull stats of loadbalaner can be viwed via browser on 8080 port.

cons:

Could have been better if installation of services was done by any CM tool like ansible, chef, puppet to avoid manual interruptions.
A high availability (HA) of loadbalancer setup could have hepled in avoiding a single point failure of LB.
####################################################################################################